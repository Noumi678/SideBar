package com.example.untitled10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
